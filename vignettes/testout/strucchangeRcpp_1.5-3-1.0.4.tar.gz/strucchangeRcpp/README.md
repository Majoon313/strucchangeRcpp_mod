# strucchange
This repository is a fork of the R package [strucchange](https://cran.r-project.org/package=strucchange) [1]. A few modifications will try to improve computationally intensive functions such as `recresid.default`.

## References 
[1] Zeileis, A., Leisch, F., Hornik, K., & Kleiber, C. (2002). strucchange: An R Package for Testing for Structural Change in Linear Regression Models. Journal of Statistical Software, 7(2), 1 - 38. doi:http://dx.doi.org/10.18637/jss.v007.i02


